<?php
error_reporting(0);
include 'connect.php'; // Include the database connection

// Retrieve USSD parameters
$sessionId = $_POST["sessionId"];
$serviceCode = $_POST["serviceCode"];
$phoneNumber = $_POST["phoneNumber"];
$text = $_POST["text"];

// Break down the input text
$textArray = explode("*", $text);
$level = count($textArray);

// USSD Menu Logic
if ($text == "") {
    // Initial menu
    $response = "CON Welcome To SMARTWALLET\n";
    $response .= "1. Register\n";
    $response .= "2. Check Balance\n";
    $response .= "3. Deposit Money\n";
    $response .= "4. Send Money\n";
    $response .= "5. Exit";
}
//Register Menu
else if ($text == "1") {
    // Registration Step 1: Prompt for Name
    $response = "CON Enter your full name:";
} else if ($level == 2 && $textArray[0] == "1") {
    // Registration Step 2: Prompt for PIN
    $name = $textArray[1];
    $response = "CON Enter your 4-digit PIN:";	
} else if ($level == 3 && $textArray[0] == "1") {
    // Registration Step 3: Confirm PIN
    $name = $textArray[1];
    $pin = $textArray[2];
    $response = "CON Confirm your 4-digit PIN:";
} else if ($level == 4 && $textArray[0] == "1") {
    // Finalize Registration
    $name = $textArray[1];
    $pin = $textArray[2];
    $confirmPin = $textArray[3];
if ($pin == $confirmPin) {
        // Check if the user already exists
        $checkUser = "SELECT * FROM users WHERE phone_number = '$phoneNumber'";
        $result = $conn->query($checkUser);

        if ($result->num_rows > 0) {
            $response = "END You are already registered.";
        } else {
            // Insert new user into the database
            $stmt = $conn->prepare("INSERT INTO users (phone_number, names, PIN, balance) VALUES (?, ?, ?, ?)");
            $defaultBalance = 0.00;
            $stmt->bind_param("ssdi", $phoneNumber, $name, $pin, $defaultBalance);

            if ($stmt->execute()) {
                $response = "END Registration successful. Welcome, $name!";
            } else {
                $response = "END Registration failed. Please try again.";
            }
            $stmt->close();
        }
    } else {
        $response = "END PINs do not match. Please restart registration.";
    }	
}
// Check Balance
else if ($text == "2") {
    // Step 1: Prompt for PIN to check balance
    $response = "CON Enter your PIN to check balance:";
} else if ($level == 2 && $textArray[0] == "2") {
    // Step 2: Validate PIN and display balance
    $pin = $textArray[1];

    // Check if the user exists and the PIN matches
    $query = "SELECT balance, PIN FROM users WHERE phone_number = '$phoneNumber'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user['PIN'] == $pin) {
            $balance = $user['balance'];
            $response = "END Your balance is: $balance";
        } else {
            $response = "END Invalid PIN. Please try again.";
        }
    }
	else {
        $response = "END User not found. Please register first.";
    }
}
// Deposit Money - Prompt for amount
else if ($text == "3") {
    // Step 1: Prompt for deposit amount
    $response = "CON Enter the amount to deposit:";
} else if ($level == 2 && $textArray[0] == "3") {
    // Step 2: Prompt for PIN
    $depositAmount = $textArray[1];
    $response = "CON Enter your PIN to confirm the deposit:";
} else if ($level == 3 && $textArray[0] == "3") {
    // Step 3: Show confirmation menu
    $depositAmount = $textArray[1];
    $pin = $textArray[2];

    // Verify the PIN
    $query = "SELECT balance, PIN FROM users WHERE phone_number = '$phoneNumber'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user['PIN'] == $pin) {
            $response = "CON You are about to deposit $depositAmount\n";
            $response .= "1. Confirm\n";
            $response .= "2. Cancel";
        } else {
            $response = "END Invalid PIN. Deposit not processed.";
        }
    } else {
        $response = "END User not found. Please register first.";
    }
} else if ($level == 4 && $textArray[0] == "3") {
    // Step 4: Process confirmation
    $depositAmount = $textArray[1];
    $pin = $textArray[2];
    $confirmation = $textArray[3];

    if ($confirmation == "1") {
        // Confirm deposit and update balance
        $query = "SELECT balance FROM users WHERE phone_number = '$phoneNumber'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $newBalance = $user['balance'] + $depositAmount;

            $updateQuery = "UPDATE users SET balance = $newBalance WHERE phone_number = '$phoneNumber'";
            if ($conn->query($updateQuery) === TRUE) {
                $response = "END Deposit of $depositAmount was successful. Your new balance is: $newBalance";
            } else {
                $response = "END Deposit failed. Please try again.";
            }
        } else {
            $response = "END User not found. Please register first.";
        }
    } else if ($confirmation == "2") {
        // Cancel deposit
        $response = "END Deposit canceled. Returning to main menu.";
    } else {
        $response = "END Invalid input. Please try again.";
}}
// Send Money	
else if ($text == "4") {
    // Step 1: Ask for recipient's phone number
    $response = "CON Enter recipient's phone number:";
} else if ($level == 2 && $textArray[0] == "4") {
    // Step 2: Ask for amount to send
    $recipientPhone = $textArray[1];
    $response = "CON Enter the amount to send:";
} else if ($level == 3 && $textArray[0] == "4") {
    // Step 3: Ask for PIN
    $recipientPhone = $textArray[1];
    $amount = $textArray[2];
    $response = "CON Enter your PIN to confirm:";
} else if ($level == 4 && $textArray[0] == "4") {
    // Step 4: Show confirmation menu
    $recipientPhone = $textArray[1];
    $amount = $textArray[2];
    $pin = $textArray[3];

    // Validate PIN
    $query = "SELECT balance, PIN FROM users WHERE phone_number = '$phoneNumber'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user['PIN'] == $pin) {
            // PIN is valid, show confirmation menu
            $response = "CON You are about to send $amount to $recipientPhone\n";
            $response .= "1. Confirm\n";
            $response .= "0. Back\n";
            $response .= "00. Main Menu";
        } else {
            $response = "END Invalid PIN. Transaction not processed.";
        }
    } else {
        $response = "END User not found. Please register first.";
    }
} else if ($level == 5 && $textArray[0] == "4") {
    // Step 5: Process confirmation
    $recipientPhone = $textArray[1];
    $amount = $textArray[2];
    $pin = $textArray[3];
    $confirmation = $textArray[4];

    if ($confirmation == "1") {
        // Confirm transaction
        $querySender = "SELECT balance FROM users WHERE phone_number = '$phoneNumber'";
        $queryRecipient = "SELECT balance FROM users WHERE phone_number = '$recipientPhone'";

        $resultSender = $conn->query($querySender);
        $resultRecipient = $conn->query($queryRecipient);

        if ($resultSender->num_rows > 0 && $resultRecipient->num_rows > 0) {
            $sender = $resultSender->fetch_assoc();
            $recipient = $resultRecipient->fetch_assoc();

            if ($sender['balance'] >= $amount) {
                // Deduct from sender's balance
                $newSenderBalance = $sender['balance'] - $amount;
                $updateSender = "UPDATE users SET balance = $newSenderBalance WHERE phone_number = '$phoneNumber'";

                // Add to recipient's balance
                $newRecipientBalance = $recipient['balance'] + $amount;
                $updateRecipient = "UPDATE users SET balance = $newRecipientBalance WHERE phone_number = '$recipientPhone'";

                if ($conn->query($updateSender) === TRUE && $conn->query($updateRecipient) === TRUE) {
                    // Log transaction
                    $logQuery = "INSERT INTO transactions (sender, recipient, amount, type) 
                                 VALUES ('$phoneNumber', '$recipientPhone', $amount, 'transfer')";
                    if ($conn->query($logQuery) === TRUE) {
                        $response = "END Money sent successfully. Your new balance is: $newSenderBalance";
                    } else {
                        $response = "END Money sent, but transaction logging failed.";
                    }
                } else {
                    $response = "END Transaction failed. Please try again.";
                }
            } else {
                $response = "END Insufficient balance. Transaction not processed.";
            }
        } else {
            $response = "END Invalid recipient. Transaction not processed.";
        }
    } else if ($confirmation == "0") {
        // Back to amount input
        $response = "CON Enter the amount to send:";
    } else if ($confirmation == "00") {
        // Back to main menu
        $response = "CON Welcome to USSD Service\n";
        $response .= "1. Register\n";
        $response .= "2. Check Balance\n";
        $response .= "3. Deposit Money\n";
        $response .= "4. Send Money\n";
        $response .= "5. Exit";
    } else {
        $response = "END Invalid input. Please try again.";
    }
	
// Exit Menu	
} else if ($text == "5") {
    
    $response = "END Thank you for using our service!";
} else {
    // Invalid input
    $response = "END Invalid choice!";
}

// Send the response back
header('Content-type: text/plain');
echo $response;
?>